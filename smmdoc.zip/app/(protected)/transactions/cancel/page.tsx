export default function page() {
  return <div>cancel</div>;
}
